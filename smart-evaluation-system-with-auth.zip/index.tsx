
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// نلاحظ هنا أنه لا يوجد import لأي ملف CSS خارجي غير موجود
// الاعتماد كلياً على Tailwind CSS من الرابط في index.html

const rootElement = document.getElementById('root');
if (!rootElement) {
    console.error("Critical Error: Root element not found!");
} else {
    const root = ReactDOM.createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
}
